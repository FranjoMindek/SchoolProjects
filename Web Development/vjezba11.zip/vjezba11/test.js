async function test() {
    return Math.random();
}
test()
.then( x => console.log(x) )
.catch( x => console.log(x) )

let testiranje = new Promise((ok, err) => {
    if(Math.random() > 0.5) ok('da')
    else err('ne')
})
testiranje.then( ok => console.log('yay ' + ok)).catch( err => console.log('tugi ' + err))
const express = require('express');
const router = express.Router();

router.get('/', function (req, res, next) {
    console.log('bruh');
    res.write('assets');
    res.end();
});

module.exports = router;
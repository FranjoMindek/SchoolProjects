const express = require('express');
const app = express();
const assetsRoute = require('./assets.routes');
app.use(express.urlencoded({ extended: true }));

app.use('/assets', assetsRoute);


app.listen(3000);

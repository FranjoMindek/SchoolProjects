package com.example.aggregatormicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AggregatorMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}

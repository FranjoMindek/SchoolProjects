from TextEditorWindow import TextEditorWindow


my_window = TextEditorWindow()
my_window.loop()



